$(document).ready(function () {
   $('.slider').slick({
      dots: true
   });
});

$(document).ready(function () {
   $('.slider_m').slick({
      slidesToShow: 4,
      slidesToScroll: 1,
      infinite: false
   });
});